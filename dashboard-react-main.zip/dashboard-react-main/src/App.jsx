
import { useState } from 'react';
import Dashboard from './pages/Dashboard';
import Gestion from './pages/Gestion';
import Configuracion from './pages/Configuracion';

function App() {
  const [pagina, setPagina] = useState('dashboard');

  const renderizarPagina = () => {
    switch (pagina) {
      case 'dashboard':
        return <Dashboard />;
      case 'gestion':
        return <Gestion />;
      case 'configuracion':
        return <Configuracion />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div>
      <nav style={{ display: 'flex', gap: '1rem', marginBottom: '1rem' }}>
        <button onClick={() => setPagina('dashboard')}>Dashboard</button>
        <button onClick={() => setPagina('gestion')}>Gestión</button>
        <button onClick={() => setPagina('configuracion')}>Configuración</button>
      </nav>

      <main>
        {renderizarPagina()}
      </main>
    </div>
  );
}

export default App;

