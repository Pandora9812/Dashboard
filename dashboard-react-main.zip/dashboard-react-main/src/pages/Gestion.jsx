
function Gestion() {
    return (
      <div>
        <h1>Página de Gestión</h1>
        <p>Aquí podrías administrar los datos o usuarios.</p>
      </div>
    );
  }
  
  export default Gestion;
  