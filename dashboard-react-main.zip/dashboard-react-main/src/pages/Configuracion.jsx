import { useState } from 'react';
import { useAppContext } from '../context/AppContext';

function Configuracion() {
  const { state, dispatch } = useAppContext();
  const [input, setInput] = useState('');

  const manejarEnvio = (e) => {
    e.preventDefault();
    dispatch({ type: 'guardar_informacion', payload: input });
    setInput('');
  };

  return (
    <div style={estilos.fondo}>
      <div style={estilos.cuadro}>
        <h1 style={estilos.titulo}>Configuración</h1>

        <form onSubmit={manejarEnvio} style={estilos.formulario}>
          <label style={estilos.label}>
            Ingresa información:
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Escribe algo..."
              style={estilos.input}
            />
          </label>
          <button type="submit" style={estilos.boton}>Guardar</button>
        </form>

        {state.informacion && (
          <div style={estilos.resultado}>
            <strong>Información guardada:</strong>
            <p>{state.informacion}</p>
          </div>
        )}
      </div>
    </div>
  );
}

const estilos = {
  fondo: {
    backgroundColor: '#f0f0f0',
    minHeight: '100vh',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  cuadro: {
    backgroundColor: '#fff',
    padding: '2rem',
    borderRadius: '12px',
    boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
    width: '100%',
    maxWidth: '400px',
    textAlign: 'center',
  },
  titulo: {
    marginBottom: '1.5rem',
    fontSize: '1.5rem',
    color: '#333',
  },
  formulario: {
    display: 'flex',
    flexDirection: 'column',
    gap: '1rem',
  },
  label: {
    fontSize: '1rem',
    color: '#555',
  },
  input: {
    padding: '0.5rem',
    borderRadius: '6px',
    border: '1px solid #ccc',
    width: '100%',
    marginTop: '0.5rem',
  },
  boton: {
    backgroundColor: '#007bff',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    padding: '0.6rem',
    cursor: 'pointer',
    transition: 'background-color 0.3s',
  },
  resultado: {
    marginTop: '1.5rem',
    color: '#333',
  },
};

export default Configuracion;
