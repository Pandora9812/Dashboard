import GraficoLineas from '../components/GraficoLineas';

function Dashboard() {
  return (
    <div>
      <h1>Estadísticas</h1>
      <GraficoLineas />
    </div>
  );
}

export default Dashboard;


  