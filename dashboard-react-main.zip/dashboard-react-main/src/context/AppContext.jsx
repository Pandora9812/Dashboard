
import { createContext, useContext, useReducer } from 'react';


const initialState = {
  usuario: 'Invitado',
  contador: 0,
};


function appReducer(state, action) {
  switch (action.type) {
    case 'incrementar':
      return { ...state, contador: state.contador + 1 };
    default:
      return state;
  }
}


const AppContext = createContext();


export function AppProvider({ children }) {
  const [state, dispatch] = useReducer(appReducer, initialState);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
}


export function useAppContext() {
  return useContext(AppContext);
}
